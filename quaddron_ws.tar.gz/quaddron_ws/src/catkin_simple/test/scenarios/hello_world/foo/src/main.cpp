#include <bar/hello.h>
#include <baz/world.h>

int main(void) {
    hello();
    world();

    return 0;
}