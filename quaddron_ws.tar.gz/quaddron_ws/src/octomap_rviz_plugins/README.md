octomap_rviz_plugins [![CI](https://github.com/octomap/octomap_rviz_plugins/workflows/CI/badge.svg)](https://github.com/octomap/octomap_rviz_plugins/actions?query=workflow%3ACI)
====================

RViz display plugins for visualizing octomap messages (ROS groovy and later):
http://ros.org/wiki/octomap_rviz_plugins
