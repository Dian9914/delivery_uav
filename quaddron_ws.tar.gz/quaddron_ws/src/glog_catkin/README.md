glog_catkin
===========

A catkin wrapper of the Google glog library: https://github.com/google/glog.
