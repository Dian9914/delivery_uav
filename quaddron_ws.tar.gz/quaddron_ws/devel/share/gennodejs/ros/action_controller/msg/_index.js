
"use strict";

let MultiDofFollowJointTrajectoryFeedback = require('./MultiDofFollowJointTrajectoryFeedback.js');
let MultiDofFollowJointTrajectoryAction = require('./MultiDofFollowJointTrajectoryAction.js');
let MultiDofFollowJointTrajectoryGoal = require('./MultiDofFollowJointTrajectoryGoal.js');
let MultiDofFollowJointTrajectoryActionGoal = require('./MultiDofFollowJointTrajectoryActionGoal.js');
let MultiDofFollowJointTrajectoryResult = require('./MultiDofFollowJointTrajectoryResult.js');
let MultiDofFollowJointTrajectoryActionResult = require('./MultiDofFollowJointTrajectoryActionResult.js');
let MultiDofFollowJointTrajectoryActionFeedback = require('./MultiDofFollowJointTrajectoryActionFeedback.js');
let MultiDofFollowJointTrajectoryFeedback = require('./MultiDofFollowJointTrajectoryFeedback.js');
let MultiDofFollowJointTrajectoryAction = require('./MultiDofFollowJointTrajectoryAction.js');
let MultiDofFollowJointTrajectoryGoal = require('./MultiDofFollowJointTrajectoryGoal.js');
let MultiDofFollowJointTrajectoryActionGoal = require('./MultiDofFollowJointTrajectoryActionGoal.js');
let MultiDofFollowJointTrajectoryResult = require('./MultiDofFollowJointTrajectoryResult.js');
let MultiDofFollowJointTrajectoryActionResult = require('./MultiDofFollowJointTrajectoryActionResult.js');
let MultiDofFollowJointTrajectoryActionFeedback = require('./MultiDofFollowJointTrajectoryActionFeedback.js');

module.exports = {
  MultiDofFollowJointTrajectoryFeedback: MultiDofFollowJointTrajectoryFeedback,
  MultiDofFollowJointTrajectoryAction: MultiDofFollowJointTrajectoryAction,
  MultiDofFollowJointTrajectoryGoal: MultiDofFollowJointTrajectoryGoal,
  MultiDofFollowJointTrajectoryActionGoal: MultiDofFollowJointTrajectoryActionGoal,
  MultiDofFollowJointTrajectoryResult: MultiDofFollowJointTrajectoryResult,
  MultiDofFollowJointTrajectoryActionResult: MultiDofFollowJointTrajectoryActionResult,
  MultiDofFollowJointTrajectoryActionFeedback: MultiDofFollowJointTrajectoryActionFeedback,
  MultiDofFollowJointTrajectoryFeedback: MultiDofFollowJointTrajectoryFeedback,
  MultiDofFollowJointTrajectoryAction: MultiDofFollowJointTrajectoryAction,
  MultiDofFollowJointTrajectoryGoal: MultiDofFollowJointTrajectoryGoal,
  MultiDofFollowJointTrajectoryActionGoal: MultiDofFollowJointTrajectoryActionGoal,
  MultiDofFollowJointTrajectoryResult: MultiDofFollowJointTrajectoryResult,
  MultiDofFollowJointTrajectoryActionResult: MultiDofFollowJointTrajectoryActionResult,
  MultiDofFollowJointTrajectoryActionFeedback: MultiDofFollowJointTrajectoryActionFeedback,
};
